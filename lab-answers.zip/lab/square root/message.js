
    function root(){
            var n=prompt("Enter the Limit", "10");
            for(i=1;i<=n;i++){
                        document.write("<center>"+i+"<sup>2</sup> = "+i*i);
    }}